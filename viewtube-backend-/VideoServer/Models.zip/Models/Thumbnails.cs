﻿namespace VideoServer.Models
{
    public class Thumbnails
    {
        public Default Default { get; set; }
        public High High { get; set; }
        public Standard Standard { get; set; }

    }

    public class Default
    {
        public string Url { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
    }

    public class High
    {
        public string Url { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
    }

    public class Standard
    {
        public string Url { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
    }

}









