﻿namespace VideoServer.Models
{
    public class Item
    {
        public string Etag { get; set; }
        public string Id { get; set; }
        public Snippet Snippet { get; set; }
    }

}









