﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VideoServer.Models
{
    public class VideoModel
    {
        public string Etag { get; set; }
        public Item[] Items { get; set; }
    }

    public class Default
    {
        public string Url { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
    }


    public class High
    {
        public string Url { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
    }

    public class Standard
    {
        public string Url { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
    }

}









